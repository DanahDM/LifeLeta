<?php

    namespace App\Models;

    use Google\Cloud\Firestore\FirestoreClient;
    use Google\Cloud\Firestore\DocumentReference;
    use Google\Cloud\Firestore\CollectionReference;
    use Google\Cloud\Firestore\auth;

    class Firestore
    {
        public FirestoreClient $firestore;
        private string $collectionName;
        private string $documentName;

        public function __construct()
        {
            $this->firestore = new FirestoreClient([
                "keyFilePath" => "Keys\lifleta-b0341-8e070bca4e68.json",
                "projectId" => "lifleta-b0341",
            ]);
        }

        public function setCollectionName(string $collectionName): Firestore
        {
            $this->collectionName = $collectionName;
            return $this;
        }

        public function setDocumentName(string $documentName): Firestore
        {
            $this->documentName = $documentName;
            return $this;
        }

        public function getDocument(): ?DocumentReference
        {
            if (empty($this->documentName))  return null;

            $collaction = $this->firestore->collection($this->collectionName);
            if (!$collaction->documents()->isEmpty()) {
                return $collaction->document($this->documentName);
            }
            return null;
        }

        public function getData(string $key = "")
        {
            if (!empty($key)) {
                return $this->getDocument()->snapshot()->get($key);
            } else {
                return $this->getDocument()->snapshot()->data();
            }
        }

        public function addDocument(array $data)
        {
            if (empty($this->collectionName)) {
                $result = 'هذه المجموعة غير موجودة بقاعدة البيانات';
                echo '<script> alert("' . $result . '"); </script>';
            } else {
                $this->firestore->collection($this->collectionName)->add($data)->id();
                $result = ("تم إضافة السجل في قاعدة البيانات بنجاح.");
                echo '<script> alert("' . $result . '"); </script>';
            }
        }
        public function deleteDocument(string $name)
        {
            if (empty($this->collectionName)) {
                $result = 'هذه المجموعة غير موجودة بقاعدة البيانات';
                echo '<script> alert("' . $result . '"); </script>';
            } else if (empty($this->documentName)) {
                $result = 'هذا السجل غير موجود في قاعدة البيانات. ';
                echo '<script> alert("' . $result . '"); </script>';
            } else {
                $this->firestore->collection($this->collectionName)->document($name)->delete();
                $result = ("تم حذف السجل "  . $name . "  من قاعدة البيانات بنجاح.");
                echo '<script> alert("' . $result . '"); </script>';
            }
        }

        public function updateDocument(string $name, array $data)
        {
            if (empty($this->collectionName)) {
                $result = 'هذه المجموعة غير موجودة بقاعدة البيانات';
                echo '<script> alert("' . $result . '"); </script>';
            } else {
                $addedDocRef = $this->firestore->collection($this->collectionName)->document($name);
                $documentSnapshot = $addedDocRef->snapshot();
                if (!$documentSnapshot->exists()) {
                    $result = 'هذا السجل غير موجود في قاعدة البيانات. ';
                    echo '<script> alert("' . $result . '"); </script>';
                } else {
                    $this->firestore->collection($this->collectionName)->document($name)->update($data);
                    $result = ("تم تعديل البيانات بنجاح.");
                    echo '<script> alert("' . $result . '"); </script>';
                }
            }
        }

        public function register(array $data): string
        {
            $uid = $data['ID'];
            $addedDocRef = $this->firestore->collection($this->collectionName)->document($uid);
            $documentSnapshot = $addedDocRef->snapshot();
            if ($documentSnapshot->exists()) {
                return 'هذا الهوية مسجلة بالفعل في قاعدة البيانات';
            } else {
                // إنشاء وثيقة جديدة مع ID محدد
                $addedDocRef->set($data);
                return ('تم إنشاء وثيقة جديدة في Firestore بنجاح مع ID: ' . $uid);
            }
        }


        public function login(array $data)
        {
            $docRef = $this->firestore->collection($this->collectionName)->document($data['ID']);
            $snapshot = $docRef->snapshot();
            if ($snapshot->exists()) {
                // تحقق من صحة كلمة المرور المدخلة
                $getdata = $snapshot->data();
                $storedPassword = $getdata['Password'];
                $loginPassword = $data['Password'];
                // قارن كلمة المرور
                if ($loginPassword === $storedPassword) {
                    $result = " تم تسجيل الدخول بنجاح ";
                    session_start();
                    $_SESSION['user'] = $data['ID'];
                    echo '<script> alert("' . $result . '"); </script>';
                    echo "<script>window.open('homepage.php','_self')</script>";
                } else {
                    $result =  'كلمة المرور غير صحيحة';
                    echo '<script> alert("' . $result . '"); </script>';
                }
            } else {
                $result =  'لا يوجد مستخدم مسجل بهذه المعلومات';
                echo '<script> alert("' . $result . '"); </script>';
            }
        }
    }

?>