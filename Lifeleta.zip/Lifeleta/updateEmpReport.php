<?php

use App\Models\Firestore;

require_once "vendor/autoload.php";
$db = new Firestore();

if (isset($_POST['updateId'])&& isset($_POST['updateModalInput'])) {
    
    $updateId = $_POST['updateId'];
    $status = $_POST['updateModalInput'];

    if ($status === ''){
        $status = "Processing";
    }

    $collection = $db->setCollectionName('Report');

    $data = [
        ['path' => 'status', 'value' => $status],
    ];

    $collection->updateDocument($updateId, $data);
    
}

?>