<?php
    include_once("./includes/header.php");

    use App\Models\Firestore;

    if (isset($_POST['addSensor'])) {
        require_once "vendor/autoload.php";
        $db = new Firestore();
        $collection = $db->setCollectionName('Sensors');

        $SensorName = $_POST['SensorName'];
        $SensorAddress = $_POST['SensorAddress'];
        $SensorLevel = $_POST['SensorLevel'];

        $data = [
            'SensorName' => $SensorName,
            'SensorAddress' => $SensorAddress,
            'SensorLevel' => $SensorLevel
        ];

        $collection->addDocument($data);

        echo "<script>window.open('sensors.php?sensors','_self')</script>";
    }
?>

<body class="bg-white">
    <div class="login1">
        <img class="login-child" alt="not found" src="./public/rectangle-120@2x.png">
        <b class="b1 mt-1"> إضافة حساس </b>
    </div>
    <div class="container-fluid">
        <div class="text-center">
            <img src="./public/logo1@2x.png" width="220px" height="130px" class="align-top" alt="Logo" loading="lazy">
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <form class="mt-4 needs-validation" id="senform" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" style="font-size: var(--font-size-xs); gap: 20px;">
                    <div class="idlog pt-4">
                        <label for="SensorName" class="form-label pslog"> اسم الحساس </label>
                        <div class="inputl">
                            <input type="text" class="form-control inputidlog" id="SensorName" name="SensorName" placeholder="ادخل اسم الحساس" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" required />
                        </div>
                    </div>
                    <div class="idlog pt-4 pb-3">
                        <label for="SensorAddress" class="form-label pslog"> موقع الحساس </label>
                        <div class="inputl">
                            <input type="text" class="form-control inputidlog" id="SensorAddress" name="SensorAddress" placeholder="ادخل موقع الحساس" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" required />
                        </div>
                    </div>
                    <div class="idlog pt-4">
                        <label for="SensorLevel" class="form-label pslog"> مستوى الحساس </label>
                        <div class="inputl">
                            <input type="number" class="form-control inputidlog" id="SensorLevel" name="SensorLevel" placeholder="ادخل مستوى الحساس" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" required />
                        </div>
                    </div>
                    <div class="col pt-4">
                        <div class="text-center">
                            <button type="submit" class="btn btn-secondary btnl" name="addSensor" value="addSensor">
                                إضافة الحساس </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="d-flex  mt-5">
        <img alt="" src="./public/frame-7042.svg" width="100%">
    </div>
    <script>
        window.addEventListener('DOMContentLoaded', (event) => {
            document.documentElement.setAttribute('data-bs-theme', 'light');
        });
    </script>

</body>

</html>