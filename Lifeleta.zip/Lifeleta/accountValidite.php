<?php
include_once("./includes/header.php");

    $ID = $_POST['ID'];
    $Phone = $_POST['Phone'];
    $password = $_POST['password'];


require_once "vendor/autoload.php";

use App\Models\Firestore;

$db = new Firestore();

$data = [
    'AdminID' => $ID,
    'Password' => $password,
    'Phone' => $Phone,
];

//$collection = $db->addDocument("Admin", $data);

?>

<body class="bg-white">
    <div class="container-fluid">
        <div class="text-center mt-5 p-4">
            <div class=" align-content-center">
                <img src="./public/logo1@2x.png" width="220px" height="130px" class="align-top" alt="Logo"
                    loading="lazy">
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center gap-5">
            <div class="col-md-3 ">
                <div class=" p-3 mt-4 text-center ">
                    <span class=" ms-3 me-3 "
                        style="line-height: 24px; color: #000000; font-size: 24px; font-weight: 800; font-family: 'Inter';">
                        أدخل رمز التحقق المرسل إلى </span> <br><br>
                    <span class="ms-5 me-5 p-4 dir" dir='ltr'
                        style="font-style: normal; font-weight: 400; font-size: 14px; line-height: 21px; color: #B7B7B7; font-family: var(--font-poppins);">
                        <?php echo $Phone; ?> </span> <br>
                </div>
                <form class="needs-validation">
                    <div class="col text-center">
                        <input type="text" class="inputidlog form-control" id="val1" required />
                        <input type="text" class="inputidlog form-control" id="val2" required />
                        <input type="text" class="inputidlog form-control" id="val3" required />
                        <input type="text" class="inputidlog form-control" id="val4" required />
                        <br><br><br>
                    </div>
                    <div class="text-center">
                        <div class="text-center">
                            <button type="submit" class="btn btn-secondary btnl">
                                تحـقـق </button> <br>
                        </div>
                        <div class="align-content-center gap-lg-4 mt-2"
                            style="letter-spacing: 0.03em; font-weight: 600; font-size: 18px; font-family: var(--font-poppins);">
                            لم يصلك رمز؟
                            <a id="repat" href="#" class="link-dark text-dark">
                                <span class="fw-bold fs-4"> إعادة إرسال </span>
                            </a><br><br><br>
                        </div>
                        <div class="align-content-center gap-lg-4 mt-2"
                            style="letter-spacing: 0.03em; font-weight: 600; font-size: 18px; font-family: var(--font-poppins);">
                            عضو بالفعل ؟
                            <a id="reg" href="loginpage.php"
                                class="link-success link-offset-2 link-underline link-underline-opacity-0"
                                style="color: var(--color-teal);"> <span class="fw-bold fs-4"> تسجيل دخول </span>
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="d-flex  mt-5">
        <img alt="" src="./public/frame-7042.svg" width="100%">
    </div>
</body>

</html>