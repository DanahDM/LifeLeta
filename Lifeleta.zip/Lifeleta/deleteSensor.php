<?php

    use App\Models\Firestore;

    require_once "vendor/autoload.php";
    $db = new Firestore();
    $collection = $db->setCollectionName('Sensors');

    if (isset($_POST['deleteId'])) {
        // استرجاع رقم الحساس المطلوب للحذف
        $deleteId = $_POST['deleteId'];
        $data = $collection->setDocumentName($deleteId);
        // حذف المستند من Firestore باستخدام رقم الحساس كمعرف
        $data->deleteDocument($deleteId);
    }

?>
