<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");

    use App\Models\Firestore;

    require_once "vendor/autoload.php";

    $db = new Firestore();
    $db->setCollectionName('Report');

    $reportsRef = $db->firestore->collection('Report')->documents();

?>

<div class="d-flex justify-content-center py-5 m-3">
    <div class="col-md-6" style="background-color: var(--color-teal-100); border-radius: 10px;">
        <button type="button" class="btn btn-light btn2 m-3 ms-4">
            <a class="nav-link d-flex align-items-center" href="announcements-Safiex.php?announcements"> <b class="ms-4 me-4"> البلاغات
                    الجـديدة </b> </a>
        </button>
        <button type="button" class="btn btn-light btn2 m-3 ">
            <a class="nav-link d-flex align-items-center" href="announcements.php?announcements"> <b class="ms-4 me-4"> البلاغات
                    الحـالية </b> </a>
        </button>
        <button type="button" class="btn btn-light btn2 m-3" style="background-color: var(--color-silver);">
            <a class="nav-link d-flex align-items-center" href="announcements-Prefiex.php?announcements"> <b class="ms-4 me-4"> البلاغات
                    السـابقة </b> </a>
        </button>
    </div>
</div>

<div class="container-fluid pt-5 pb-3">
    <div class="row justify-content-center gap-5" style="padding-left: 0rem; padding-right: 0rem;">
        <?php foreach ($reportsRef as $reportDoc) {
            $reportData = $reportDoc->data();
            if ($reportData['status'] !== 'Implemented') {
                continue;
            }
        ?>
            <div class="row announc-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
                <div class="row justify-content-start pt-1 " style="padding-left: 0rem; padding-right: 0.5rem;">
                    <div class="col-8 pt-2">
                        <img alt="not found" src="./public/announcement.svg" height="30px">
                        <span class="ms-2" height="36px" style=" vertical-align: bottom;"> <?php echo $reportData['subject'] ?> </span>
                    </div>
                    <div class="col-9 justify-content-start">
                        <span class="announc-con ms-4 mt-2">
                            <?php
                                date_default_timezone_set('Asia/Riyadh');
                                $dateTime = date('d/m/Y - h:i A', strtotime($reportData['dateTime']));
                                echo $reportData['numReport'] . ' - ' . $dateTime;
                            ?>
                        </span>
                    </div>
                    <div class="col-2 ms-4 justify-content-end ">
                        <div class="announc-type">
                            <span class="text-center mt-2"> بلاغ سابق </span>
                        </div>
                    </div>
                    <div class="col-8 pt-4">
                        <div class="announc-text">
                            <div class="m-4 pt-3">
                                <?php echo $reportData['description'] ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-8 pt-3 ms-5 justify-content-start">
                        <img alt="not found" src="./public/address.svg" height="30px">
                        <span class="announc-con ms-2"> <?php echo $reportData['location']['country'] ?> </span>
                    </div>
                    <div class="col-md-8 pt-3 ms-5 pb-4 justify-content-md-evenly align-items-center">
                        <div class="text-center">
                            <button type="button" class="btn btn3 btn-secondary ms-5">
                                <a class="nav-link" href="display-Announcements.php?announcements&IdRep=<?php echo $reportDoc->id(); ?>"> عــرض </a>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>
</div>
<div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
</script>
<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>