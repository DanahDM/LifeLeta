<?php
  include_once("./includes/header.php");

  use App\Models\Firestore;

  if (isset($_POST['register'])) {
    require_once "vendor/autoload.php";
    $db = new Firestore();
    $collection = $db->setCollectionName('Admin');
    $ID = $_POST['ID'];
    $password = $_POST['password'];
    $phone = $_POST['Phone'];

    $data = [
      'ID' => $ID,
      'Password' => $password,
      'Phone' => $phone
    ];

    $result = $collection->register($data);

    echo '<script> alert("' . $result . '"); </script>';
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول
    echo "<script>window.open('loginpage.php','_self')</script>";
  }

?>

<body class="bg-white">
  <div class="login1">
    <img class="login-child" alt="not found" src="./public/rectangle-120@2x.png">
    <b class="b1 mt-1"> إنشاء حساب </b>
  </div>
  <div class="container-fluid">
    <div class="text-center">
      <img src="./public/logo1@2x.png" width="220px" height="130px" class="align-top" alt="Logo" loading="lazy">
    </div>
  </div>

  <div class="container">
    <form class="row g-2 mt-4 needs-validation" id="myForm" method="post" style="font-size: var(--font-size-xs); margin-right: 250px; gap: 20px;" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <div class="col-md-5 idlog pt-4">
        <label for="ID" class="form-label pslog"> الرقم التعريفي</label>
        <div class="inputl">
          <input type="number" class="form-control inputidlog" name="ID" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" id="ID" placeholder="أدخل الرقم التعريفي" required>
        </div>
      </div>
      <div class="col-md-5 idlog pt-4 pb-3">
        <label for="password" class="form-label pslog">كلمة المرور</label>
        <div class="inputl">
          <input class="form-control inputidlog" name="password" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" id="password" placeholder="أدخل كلمة المرور" type="password" required>
        </div>
      </div>
      <div class="col-md-5 idlog pt-4">
        <label for="Phone" class="form-label pslog"> رقم الجوال </label>
        <div class="inputl">
          <input type="tel" class="form-control inputidlog" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" name="Phone" id="Phone" placeholder="أدخل رقم الجوال" required>
        </div>
      </div>
      <div class="col-md-5 idlog pt-4 pb-3">
        <label for="confirm-password" class="form-label pslog"> تأكيد كلمة المرور </label>
        <div class="inputl">
          <input class="form-control inputidlog" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" name="confirm-password" id="confirm-password" placeholder="أدخل كلمة المرور" type="password" required>
        </div>
        <span class="invalid-feedback ms-5" id="alert" style="display: block;"> </span>
        <div class="invalid-feedback">
          <i class="bi bi-x-circle-fill text-black"></i>
        </div>
        <div class="valid-feedback">
          <i class="bi bi-check-circle-fill text-black"></i>
        </div>
      </div>
      <div class="col-md-10">
        <div class="text-center">
          <button type="submit" class="btn btn-secondary btnl" name="register" value="register" onclick="onSubmit()">
            إنشاء الحساب
          </button>
        </div>
      </div>
    </form>
  </div>
  <div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
  </div>
  <script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm-password");

    function validatePassword() {
      if (password.value != confirm_password.value) {
        confirm_password.setCustomValidity("");
        confirm_password.classList.remove("is-valid");
        confirm_password.classList.add("is-invalid");
      } else {
        confirm_password.setCustomValidity("");
        confirm_password.classList.remove("is-invalid");
        confirm_password.classList.add("is-valid");
      }
    }

    password.onkeyup = validatePassword;
    confirm_password.onkeyup = validatePassword;
    var form = document.getElementById("myForm");

    function onSubmit() {
      var alert = document.getElementById("alert");
      form.addEventListener("submit", function(event) {

        if (password.value === confirm_password.value) {
          form.submit();
        } else {
          event.preventDefault();
          alert.textContent = "كلمة السر غير مطابقة يرجى ادخال نفس كلمة السر.";
          alert.classList.add("alert-danger");
          alert.classList.remove("d-none");
        }
      });
    }
  </script>

  <script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./bootstrap/js/bootstrap.min.js"></script>
</body>

</html>