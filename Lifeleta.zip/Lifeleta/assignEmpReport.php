<?php

    use App\Models\Firestore;

    require_once "vendor/autoload.php";
    $db = new Firestore();

    if (isset($_POST['empId'])&& isset($_POST['reportid'])) {
        $empId = $_POST['empId'];
        $reportid = $_POST['reportid'];
        $collection = $db->setCollectionName('Report');

        $data = [
            ['path' => 'idEmployee', 'value' => $empId],
            ['path' => 'status', 'value' => 'Processing'],
        ];

        $collection->updateDocument($reportid, $data);
        
    }

?>