<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");

    use App\Models\Firestore;

    require_once "vendor/autoload.php";

    $db = new Firestore();
    $db->setCollectionName('Report');

    $reportsRef = $db->firestore->collection('Report')->documents();

    $employeesRef = $db->firestore->collection('Employee')->documents();
    $employeesData = [];

    foreach ($employeesRef as $employeeDoc) {
        $employeeData = $employeeDoc->data();

        // استعلام قاعدة البيانات للحصول على عدد البلاغات المنفذة باسم الموظف
        $implementedReportsRef = $db->firestore->collection('Report')
            ->where('idEmployee', '=', $employeeData['id'])
            ->where('status', '=', 'Implemented')
            ->documents();

        $implementedReports = $implementedReportsRef->size();


        // استعلام قاعدة البيانات للحصول على عدد البلاغات المسجلة باسم الموظف
        $processingReportsRef = $db->firestore->collection('Report')
            ->where('idEmployee', '=', $employeeData['id'])
            ->where('status', '=', 'Processing')
            ->documents();

        $processingReports = $processingReportsRef->size();

        // إضافة البيانات إلى مصفوفة الموظفين
        $employeesData[] = [
            'employeeId' => $employeeData['id'],
            'name' => $employeeData['name'],
            'processingReports' => $processingReports,
            'implementedReports' => $implementedReports,
        ];
    }

?>
<div class="frame4 mt-5">
    <div class="frame5">
        <div class="frame-inner">
            <img class="rectangle-icon1" alt="" src="./public/rectangle-117.svg">
        </div>
        <div class="parent pt-3">
            <b class="b2"> سجل الموظفين </b>
        </div>
    </div>
    <div class="rectangle-parent8">
        <div class="text-end ">
            <button type="submit" class="btn btn-secondary btnl" id="edits" disabled>
                تحرير </button>
        </div>
    </div>
</div>

<div class="container p-1 m-5">
    <table class="table p-3 ms-5 " style="width:93%;  gap: 30px; display: grid; --bs-table-bg: unset;">
        <thead class="tableh align-middle" style=" display:grid;">
            <tr style=" display: inline-table;">
                <th class="col-3"> <span class="ms-3"> اسم الموظف </span> </th>
                <th class="col-3 text-center"> عدد الحالات المسجلة </th>
                <th class="col-3 text-center"> عدد الحالات المنفذة </th>
                <th class="col-5"> </th>
                <th class="col-1 text-end"> </th>
            </tr>
        </thead>
        <tbody class="align-middle" style="gap: 30px; display: grid;">
            <?php foreach ($employeesData as $employee) : ?>
                <tr class="tabled ">
                    <td class="col-3"> <span class="ms-3"> <?php echo $employee['name']; ?> </span> </td>
                    <td class="col-3 text-center"> <?php echo $employee['processingReports']; ?> </td>
                    <td class="col-3 text-center"> <?php echo $employee['implementedReports']; ?> </td>
                    <td class="col-5">
                        <div class="text-end">
                            <button type="submit" class="btn btn-secondary btnl">
                                <a class="nav-link d-flex align-items-center" href="showEmpRecord.php?EmpRecord&Idemp=<?php echo $employee['employeeId']; ?>"> سجل الموظف </a>
                            </button>
                        </div>
                    </td>
                    <td class="col-1">
                        <div class="text-end">
                            <a class="nav-link d-flex align-items-center gap-2 delete-link" data-bs-toggle="modal" data-bs-target="#deleteModal" href="#deleteModal">
                                <input type="hidden" class="emp-id" value="<?php echo $employee['employeeId']; ?>">
                                <input type="hidden" class="emp-name" value="<?php echo $employee['name']; ?>">
                                <svg xmlns="http: //www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 
                                0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 
                                01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 
                                1h6a1 1 0 001-1V4.059L11.882 4H4.118zM5.52V1h5v1h-5z" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<div class="modal fade delete-icon" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true" data-bs-backdrop="true">
    <div class="modal-dialog del-icon">
        <div class="modal-content border-0">
            <div class="modal-header border-0">
            </div>
            <div class="modal-body border-0 text-center" height="60px" style="margin-top: 20px; margin-bottom: 10px;">
                <span class="fw-bold"> هل أنت متأكد من حذف الموظف ؟ </span> <br>
                <span class="fw-bold text-dark "> </span>
            </div>
            <div class="modal-footer justify-content-md-evenly align-items-center border-0">
                <button type="button" class="btn btn-primary btnl"> نـعـم </button>
                <button type="button" class="btn btn-secondary btn3" data-bs-dismiss="modal"> إلغاء </button>
            </div>
        </div>
    </div>
</div>

<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
    const deleteLinks = document.querySelectorAll('.delete-link');
    deleteLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const deleteId = link.querySelector('.emp-id').value;
            const deleteName = link.querySelector('.emp-name').value;
            const deleteModal = document.getElementById('deleteModal');
            const deleteModalText = deleteModal.querySelector('.modal-body span.text-dark');
            deleteModalText.textContent = deleteName + ' .';

            const deleteButton = deleteModal.querySelector('.btn-primary');
            deleteButton.addEventListener('click', () => {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'deleteEmp.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        alert("تم حذف الموظف " + deleteName + "  من قاعدة البيانات بنجاح.");
                        deleteModal.style.display = 'none';
                        window.close();
                    }
                };
                xhr.send('deleteId=' + deleteId);
                window.open('empRecords.php?EmpRecord', '_self');
            });
        });
    });
</script>

<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>