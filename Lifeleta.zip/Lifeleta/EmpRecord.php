<?php
  include_once("./includes/header.php");
  include_once("./includes/mainnav.php");

  use App\Models\Firestore;

  require_once "vendor/autoload.php";

  $db = new Firestore();
  $db->setCollectionName('Report');

  $reportsRef = $db->firestore->collection('Report')->documents();

  $employeesRef = $db->firestore->collection('Employee')->documents();
  $employeesData = [];

  foreach ($employeesRef as $employeeDoc) {
    $employeeData = $employeeDoc->data();

    // استعلام قاعدة البيانات للحصول على عدد البلاغات المنفذة باسم الموظف
    $implementedReportsRef = $db->firestore->collection('Report')
      ->where('idEmployee', '=', $employeeData['id'])
      ->where('status', '=', 'Implemented')
      ->documents();

    $implementedReports = $implementedReportsRef->size();


    // استعلام قاعدة البيانات للحصول على عدد البلاغات المسجلة باسم الموظف
    $processingReportsRef = $db->firestore->collection('Report')
      ->where('idEmployee', '=', $employeeData['id'])
      ->where('status', '=', 'Processing')
      ->documents();

    $processingReports = $processingReportsRef->size();

    // إضافة البيانات إلى مصفوفة الموظفين
    $employeesData[] = [
      'employeeId' => $employeeData['id'],
      'name' => $employeeData['name'],
      'processingReports' => $processingReports,
      'implementedReports' => $implementedReports,
    ];
  }

?>

<div class="frame4 mt-5">
  <div class="frame5">
    <div class="frame-inner">
      <img class="rectangle-icon1" alt="" src="./public/rectangle-117.svg">
    </div>
    <div class="parent pt-3">
      <b class="b2"> سجل الموظفين </b>
    </div>
  </div>
  <div class="rectangle-parent8">
    <div class="text-end ">
      <button type="submit" class="btn btn-secondary btnl me-5" id="adds">
        <a class="nav-link d-flex align-items-center" href="empRegister.php">
          إضافة موظف </a>
      </button>
      <button type="submit" class="btn btn-secondary btnl ms-5" id="edits">
        <a class="nav-link d-flex align-items-center" href="empRecords.php?EmpRecord">
          تحرير </a>
      </button>
    </div>
  </div>
</div>

<div class="container p-1 m-5">
  <table class="table p-3 ms-5 " style="width:90%;  gap: 30px; display: grid; --bs-table-bg: unset;">
    <thead class="tableh align-middle" style=" display:grid;">
      <tr style=" display: inline-table;">
        <th class="col-3"> <span class="ms-3"> اسم الموظف </span> </th>
        <th class="col-3 text-center"> عدد الحالات المسجلة </th>
        <th class="col-3 text-center"> عدد الحالات المنفذة </th>
        <th class="col-5"> </th>
      </tr>
    </thead>
    <tbody class="align-middle " style="gap: 30px; display: grid;">
      <?php foreach ($employeesData as $employee) : ?>
        <tr class="tabled ">
          <td class="col-3"> <span class="ms-3"> <?php echo $employee['name']; ?> </span> </td>
          <td class="col-3 text-center"> <?php echo $employee['processingReports']; ?> </td>
          <td class="col-3 text-center"> <?php echo $employee['implementedReports']; ?> </td>
          <td class="col-5">
            <div class="text-end">
              <button type="submit" class="btn btn-secondary btnl">
                <a class="nav-link d-flex align-items-center" href="showEmpRecord.php?EmpRecord&Idemp=<?php echo $employee['employeeId']; ?>"> سجل الموظف </a>
              </button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="d-flex  mt-5">
  <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
</script>
<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>