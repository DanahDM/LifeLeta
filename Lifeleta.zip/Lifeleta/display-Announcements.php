<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");

    use App\Models\Firestore;

    require_once "vendor/autoload.php";

    $db = new Firestore();

    if (isset($_GET['IdRep'])) {
        $ID = $_GET['IdRep'];
        $db->setCollectionName('Report');

        $reportsRef = $db->firestore->collection('Report')->document($ID)->snapshot();

        $reportSubject = $reportsRef->get('subject');
        $reportDateTime = $reportsRef->get('dateTime');
        $reportDescription = $reportsRef->get('description');
        $reportLocation = $reportsRef->get('location')['country'];
        $reportFiles = $reportsRef->get('files');
    }

?>

<div class="container m-5 p-5">
    <div class="row justify-content-center gap-5" style="padding-left: 0rem; padding-right: 0rem;">
        <div class="row display-icon pt-4 pb-5" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
            <div class="row justify-content-start ms-1 pt-3 gap-5">
                <div class="col-11 pt-4 ms-2">
                    <b class="ms-5" height="45px"> موضوع البلاغ </b>
                </div>
            </div>
            <div class="row justify-content-start ms-4 pt-2 gap-5">
                <div class="col-11 justify-content-start ms-5 me-5 p-3 bg-body-secondary rounded-3">
                    <span class="text-dark fw-medium ms-2 p-2"> <?php echo $reportSubject ?> </span>
                </div>
            </div>
            <div class="row justify-content-start ms-2 pt-2 gap-5">
                <div class="col-11 pt-2 ms-1">
                    <b class="ms-5" height="45px"> تاريخ البلاغ </b>
                </div>
            </div>
            <div class="row justify-content-start ms-4 pt-2 gap-5">
                <div class="col-11 justify-content-start ms-5 me-5 p-3 bg-body-secondary rounded-3">
                    <b class="notf-con ms-2 p-2">
                        <?php
                            date_default_timezone_set('Asia/Riyadh');
                            $dateTime = date('d/m/Y - h:i A', strtotime($reportDateTime));
                            echo $dateTime;
                        ?>
                    </b>
                </div>
            </div>
            <div class="row justify-content-start ms-2 pt-2 gap-5">
                <div class="col-11 pt-2 ms-1">
                    <b class="ms-5" height="45px"> الوصف </b>
                </div>
            </div>
            <div class="row justify-content-start ms-4 pt-2 gap-5">
                <div class="col-11 justify-content-start ms-5 me-5 p-3 bg-body-secondary rounded-3">
                    <span class="text-dark fw-medium ms-2 mb-2 p-2"> <?php echo $reportDescription ?> </span>
                </div>
            </div>
            <div class="row justify-content-start ms-2 pt-2 gap-5">
                <div class="col-11 pt-2 ms-1">
                    <b class="ms-5" height="45px"> مرفقات </b>
                </div>
            </div>
            <div class="row justify-content-start ms-4 pt-2 gap-5">
                <div class="col-11 justify-content-start ms-5 me-5 p-3 bg-body-secondary rounded-3">
                    <?php foreach ($reportFiles as $imagesPath) : ?>
                        <img class="images" alt="" src="<?php echo $imagesPath ?>">
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="row justify-content-start ms-2 pt-2 gap-5">
                <div class="col-11 pt-2 ms-1">
                    <b class="ms-5" height="45px"> الموقع </b>
                </div>
            </div>
            <div class="row justify-content-start ms-4 pt-2 gap-5">
                <div class="col-11 justify-content-start ms-5 me-5 p-1 bg-body-secondary rounded-3">
                    <div class="text-dark fw-medium ms-4 mb-2">
                        <img alt="not found" src="./public/address.svg" height="30px">
                        <b class="notf-con ms-2 p-2"> <?php echo $reportLocation ?> </b>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
</script>
<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>