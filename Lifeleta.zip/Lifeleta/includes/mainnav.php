    <?php
        session_start();
        global $navbar_disabled;

        use App\Models\Firestore;

        if (isset($_SESSION['user']) && $_SESSION['user'] != '') {
            $navbar_disabled = false;
            $id = $_SESSION['user'];
            require_once "vendor/autoload.php";
            $db = new Firestore();
            $collection = $db->setCollectionName('Admin');
            $data = $collection->setDocumentName($id);
            $adminId = $data->getData('ID');
            $adminPhone = $data->getData('Phone');
        } else {
            $navbar_disabled = true;
        }
        if (isset($_GET['homepage'])) {
            $current_page = 'homepage';
        }
        if (isset($_GET['announcements'])) {
            $current_page = 'announcements';
        }
        if (isset($_GET['sensors'])) {
            $current_page = 'sensors';
        }
        if (isset($_GET['EmpRecord'])) {
            $current_page = 'EmpRecord';
        }
    ?>

    <body class="bg-white">
        <header class="navbar sticky-top flex-md-nowrap shadow1 p-lg-2 justify-content-lg-start fixed-top bg-white ">
            <div class="col-1">
                <img src="./public/logo@2x.png" width="100%" height="70px" class=" align-top" alt="Logo" loading="lazy">
            </div>
            <div class="col-5">
                <ul class="nav nav-pills gap-lg-4 m-lg-3 justify-content-lg-center  text-black" style="font-family: var(--font-poppins); letter-spacing: 0.03em; font-weight: 600; font-size: 18px;">
                    <li><a id="home" href="homepage.php?homepage" class="nav-link text-white a1 <?php if ($current_page === 'homepage') echo 'current-page'; ?>">الرئيسية</a></li>
                    <li><a id="blagh" href="announcements.php?announcements" class="nav-link a1 text-white <?php if ($current_page === 'announcements') echo 'current-page'; ?>">البلاغات</a></li>
                    <li><a id="sencor" href="sensors.php?sensors" class="nav-link text-white a1 <?php if ($current_page === 'sensors') echo 'current-page'; ?>">الحساسات</a></li>
                    <li><a id="record" href="EmpRecord.php?EmpRecord" class="nav-link text-white a1 <?php if ($current_page === 'EmpRecord') echo 'current-page'; ?>">سجل الموظفين</a></li>
                </ul>
            </div>
            <div class="col-sm-5 m-lg-3">
                <ul class="nav nav-pills justify-content-lg-end me-4">
                    <li class="nav-item notification-ui">
                        <a class="ellipse-parent" href="./notfications.php" id="notifications">
                            <img class="frame-child me-1" alt="not found" src="./public/ellipse-45@2x.png">
                            <img class="frame-item " alt="" src="./public/group-445.svg">
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-sm m-lg-3">
                <div class="text-end ">
                    <button class="navbar-toggler" type="button" <?php if ($navbar_disabled) echo "disabled"; ?> data-bs-toggle="offcanvas" data-bs-target="#profile" aria-controls="profile" aria-expanded="false" aria-label="Toggle navigation">
                        <img alt="not found" src="./public/vector.svg" width="100%" height="40px" />
                    </button>
                </div>
                <div class="offcanvas offcanvas-end " tabindex="-1" id="profile" aria-labelledby="profileLabel" style="width: 500px; position: fixed;">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title " id="profileLabel" dir="ltr"> My Profile </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <div class="rwo dashbord-icon pb-3 justify-content-start gap-4">
                            <div class="row justify-content-start">
                                <div class="col-md-12 text-center pt-2 mt-3">
                                    <img class="profileimage" alt="" src="./public/profile.svg">
                                </div>
                                <div class="col-md-12 pt-1 mt-2 pb-2 text-center ">
                                    <b class="fw-bold " style="color: var(--color-teal); font-size: 20px;"> المـديـر </b>
                                </div>
                            </div>
                            <div class="row justify-content-start p-4 gap-4" style="display: flex;">
                                <div class="row justify-content-start ms-3">
                                    <div class="col-md-12 dash-in-icon pt-3">
                                        <div class="fw-bolder ms-2">
                                            <img alt="not found" src="./public/Idicon.svg" height="26px">
                                            <b class="ms-2 p-1"> الرقم التعريفي </b>
                                            <b class="announc-con fw-light ms-3 p-1" dir="ltr"> <?php echo $adminId; ?> </b>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-start ms-3">
                                    <div class="col-md-12 dash-in-icon pt-3">
                                        <div class="fw-bolder ms-2">
                                            <img alt="not found" src="./public/evaPhoneFill0.svg" height="26px">
                                            <b class="ms-2 p-1"> رقم الهاتف </b>
                                            <b class="announc-con fw-light ms-4 p-1" dir="ltr"> <?php echo $adminPhone; ?> </b>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-start ms-3">
                                    <div class="col-md-12 dash-in-icon pt-3">
                                        <div class="fw-bolder ms-2">
                                            <img alt="not found" src="./public/profied.svg" height="26px">
                                            <b class="ms-2 p-1"> الدعم </b>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-start ms-3">
                                    <div class="col-md-12 dash-in-icon pt-3">
                                        <div class="fw-bolder ms-2">
                                            <img alt="not found" src="./public/accountedit.svg" height="26px">
                                            <b class="ms-2 p-1"> تعديل الحساب </b>
                                        </div>
                                    </div>
                                </div>
                                <div class="row justify-content-start ms-3">
                                    <div class="col-md-12 dash-in-icon pt-3 ">
                                        <div class="fw-bolder ms-2">
                                            <img alt="not found" src="./public/logout.svg" height="26px">
                                            <a href="logout.php" class="link-dark link-offset-2 link-underline link-underline-opacity-0" style="color: black;">
                                                <b class="ms-2 p-1"> تسجيل الخروج </b>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <script>
            var navbarDisabled = <?php echo $navbar_disabled; ?>;

            if (navbarDisabled) {
                var links = document.querySelectorAll('.nav-link');
                for (var i = 1; i < links.length; i++) {
                    links[i].classList.add('disabled');
                }

                var notificationLink = document.querySelector('#notifications');
                notificationLink.classList.add('disabled');
                notificationLink.href = '#';
            }
        </script>