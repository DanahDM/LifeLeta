<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");

    use App\Models\Firestore;

    require_once "vendor/autoload.php";

    $db = new Firestore();
    $db->setCollectionName('Sensors');

    $documents = $db->firestore->collection('Sensors')->documents();

?>

<div class="frame4 mt-5">
    <div class="frame5">
        <div class="frame-inner">
            <img class="rectangle-icon1" alt="" src="./public/rectangle-117.svg">
        </div>
        <div class="parent pt-3">
            <b class="b2"> الحساسات </b>
        </div>
    </div>
    <div class="rectangle-parent8">
        <div class="text-end ">
            <button type="submit" class="btn btn-secondary btnl me-5" id="adds">
                <a class="nav-link d-flex align-items-center" href="sensorAdd.php">
                    إضافة حساس </a>
            </button>
        </div>
    </div>
</div>

<div class="container p-1 m-5">
    <table class="table p-3 ms-5 " style="width:90%;  gap: 30px; display: grid; --bs-table-bg: unset; color: black;">
        <thead class="tableh align-middle" style=" display:grid;">
            <tr style=" display: inline-table;">
                <th class="col-4"> <span class="ms-3"> اسم الحساس </span> </th>
                <th class="col-3 text-center"> موقع الحساس </th>
                <th class="col-3 text-center"> مستوى الحساس</th>
                <th class="col-1 text-center"> </th>
                <th class="col-1 text-end"> </th>
            </tr>
        </thead>
        <tbody class="align-middle " style="gap: 30px; display: grid;">
            <?php foreach ($documents as $document) { ?>
                <tr class="tabled ">
                    <td class="col-4"> <span class="ms-3"> <?php echo $document->get('SensorName'); ?> </span> </td>
                    <td class="col-3 text-center"> <?php echo $document->get('SensorAddress'); ?> </td>
                    <td class="col-3 text-center" dir="ltr"> <?php echo $document->get('SensorLevel'); ?> CM </td>
                    <td class="col-1">
                        <div class="text-center">
                            <a class="nav-link d-flex align-items-center gap-2" href="editsencor.php?IDsen=<?php echo $document->id(); ?>">
                                <img alt="" src="./public/edit.svg" width="16" height="16">
                            </a>
                        </div>
                    </td>
                    <td class="col-1">
                        <div class="text-end">
                            <a class="nav-link delete-link d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#deleteModal" href="#deleteModal">
                                <input type="hidden" class="delete-id" value="<?php echo $document->id(); ?>">
                                <input type="hidden" class="delete-name" value="<?php echo $document->get('SensorName'); ?>">
                                <svg xmlns="http: //www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 
                                0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 
                                01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 
                                1h6a1 1 0 001-1V4.059L11.882 4H4.118zM5.52V1h5v1h-5z" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<div class="modal fade delete-icon" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true" data-bs-backdrop="true">
    <div class="modal-dialog del-icon">
        <div class="modal-content border-0">
            <div class="modal-header border-0">
            </div>
            <div class="modal-body border-0 text-center" height="60px" style="margin-top: 20px; margin-bottom: 10px;">
                <span class="fw-bold"> هل أنت متأكد من حذف الحساس ؟ </span> <br>
                <span class="fw-bold text-dark "> </span>
            </div>
            <div class="modal-footer justify-content-md-evenly align-items-center border-0">
                <button type="button" class="btn btn-primary btnl"> نـعـم </button>
                <button type="button" class="btn btn-secondary btn3" data-bs-dismiss="modal"> إلغاء </button>
            </div>
        </div>
    </div>
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
    const deleteLinks = document.querySelectorAll('.delete-link');
    deleteLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const deleteId = link.querySelector('.delete-id').value;
            const deleteName = link.querySelector('.delete-name').value;
            const deleteModal = document.getElementById('deleteModal');
            const deleteModalText = deleteModal.querySelector('.modal-body span.text-dark');
            deleteModalText.textContent = deleteName + ' من قاعدة البيانات .';

            const deleteButton = deleteModal.querySelector('.btn-primary');
            deleteButton.addEventListener('click', () => {
                // إضافة الكود التالي لاستدعاء الملف PHP وإرسال رقم الحساس للحذف
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'deleteSensor.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        alert("تم حذف السجل " + deleteName + "  من قاعدة البيانات بنجاح.");
                        deleteModal.style.display = 'none'; // إخفاء النافذة المنبثقة
                        window.close(); // إغلاق النافذة
                    }
                };
                xhr.send('deleteId=' + deleteId);
                window.open('sensors.php?sensors', '_self');
            });
        });
    });
</script>
<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>