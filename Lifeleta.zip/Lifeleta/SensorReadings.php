<?php

    use App\Models\Firestore;
    require_once "vendor/autoload.php";
    use Kreait\Firebase\Factory;
    use Google\Cloud\Firestore\FieldValue;

    $factory = (new Factory)->withDatabaseUri('https://lifleta-b0341-default-rtdb.firebaseio.com');
    $database = $factory->createDatabase();
    $reference = $database->getReference('Ultrasonic')->getValue();
    $RatioSen = $reference["Ratio"];
    $StateSen = $reference["State"];

    $db = new Firestore();
    $db->setCollectionName('SensorReadings');

    $sensorReadingsRef = $db->firestore->collection('SensorReadings')->documents();
    $sensorReadingsData = [];

    foreach ($sensorReadingsRef as $sensorReadingsDoc) {
        $existingIDs[] = $sensorReadingsDoc->id();
    }

    $existingRecordCount = 0;

    foreach ($sensorReadingsRef as $sensorReadingsDoc) {
        $found = True;
        $sensorReadData = $sensorReadingsDoc->data();
        $getRatioSen = $sensorReadData["Ratio"];
        $getStateSen = $sensorReadData["State"];
        $getChange = $sensorReadData['Change'];

        if ($getRatioSen === $RatioSen && $getChange === "Yes" && $getStateSen === "Water Level is High") {
            continue;

        } else if ($getRatioSen === $RatioSen && $getChange === "No" && $getStateSen === "Water Level is High"){
            $existingRecordCount++;
        }
        else {
            $found = False;
        }
    }

    if ( $existingRecordCount === 0 && $StateSen === "Water Level is High"){
        foreach ($sensorReadingsRef as $sensorReadingsDoc) {
            $sensorReadData = $sensorReadingsDoc->data();
            $getStateSen = $sensorReadData["State"];

            if ($getStateSen === "Water Level is High") {
                $db->firestore->collection('SensorReadings')->document($sensorReadingsDoc->id())->set([
                    'Change' => "Yes"
                ], ['merge' => true]);
            }

        }

        do {
            $id = mt_rand(100000, 999999);
            $idExists = in_array($id, $existingIDs);
        } while ($idExists);

        $data = [
            'id' => $id,
            'Ratio' => $RatioSen,
            'State' => $StateSen,
            'Change' => "No"
        ];
        $db->firestore->collection('SensorReadings')->document($id)->set($data);

        $dataRep = [
            'dateTime' => FieldValue::serverTimestamp(),
            'description' => 'مستوى الماء في الخزان عالي جدا ، بنسبة تصل إلى' . $RatioSen,
            'files' => [],
            'id' => '',
            'idEmployee' => '',
            'idUser' => '',
            'location' => [
                'country' => '',
                'country_code' => '',
                'id' => '',
                'latitude' => 0,
                'longitude' => 0,
                'postcode' => '',
                'state' => '',
                'suburb' => ''
            ],
            'notificationAdmin' => false,
            'notificationUser' => false,
            'numReport' => $id,
            'replay' => '',
            'reportType' => 'Ultrasonic',
            'states' => ['Suspended', "Processing", "Implemented"],
            'status' => 'Suspended',
            'subject' => 'بلاغ من Ultrasonic'
        ];

        $db->firestore->collection('Report')->add($dataRep)->id();
}

    if (!$found && $StateSen !== "Water Level is High"){
        foreach ($sensorReadingsRef as $sensorReadingsDoc) {
            $sensorReadData = $sensorReadingsDoc->data();
            $getStateSen = $sensorReadData["State"];
            $getChange = $sensorReadData['Change'];

            if ($getStateSen === "Water Level is High" && $getChange === "No") {
                $collection = $db->setCollectionName('SensorReadings');
                $data = [
                    ['path' => 'Change', 'value' => "Yes"],
                ];
                $db->firestore->collection('SensorReadings')->document($sensorReadingsDoc->id())->update($data);
                
            }

        }
    }

?>