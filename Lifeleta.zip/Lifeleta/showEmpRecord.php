<?php
  include_once("./includes/header.php");
  include_once("./includes/mainnav.php");

  use App\Models\Firestore;

  require_once "vendor/autoload.php";
  $db = new Firestore();

  if (isset($_GET['Idemp'])) {
    $empId = $_GET['Idemp'];
    $collection = $db->setCollectionName('Employee');
    $data = $collection->setDocumentName($empId);
    $empName = $data->getData('name');

    $empReportsRef = $db->firestore->collection('Report')
      ->where('idEmployee', '=', $empId)
      ->documents();

    $implementedRef = $db->firestore->collection('Report')
      ->where('idEmployee', '=', $empId)
      ->where('status', '=', 'Implemented')
      ->documents();

    $implementedReports = $implementedRef->size();
  }

?>

<div class="frame4 mt-5">
  <div class="frame5">
    <div class="frame-inner">
      <img class="rectangle-icon1" alt="" src="./public/rectangle-117.svg">
    </div>
    <div class="parent pt-3">
      <b class="b2"> <?php echo $empName; ?> </b>
    </div>
  </div>
</div>

<div class="container m-2 ms-5">
  <table class="table p-2 ms-5 " style="width:90%;  gap: 30px; display: grid; --bs-table-bg: unset;">
    <thead class="tableh align-middle" style=" display:grid;">
      <tr style=" display: inline-table;">
        <th class="col-3 "> <span class="ms-3"> رقم البلاغ </span> </th>
        <th class="col-3 text-center"> التاريخ </th>
        <th class="col-3 text-center"> حالة التنفيذ </th>
        <th class="col-5 text-center"> عدد الحالات المنفذة </th>
      </tr>
    </thead>
    <tbody class=" align-middle" style="gap: 30px; display: grid;">
      <?php foreach ($empReportsRef as $reportDoc) {
        $reportData = $reportDoc->data();
        if ($reportData['status'] === 'Implemented') {
          $status = ' تم التنفيذ ';
        } else {
          $status = ' لم يتم التنفيذ ';
        }
      ?>
        <tr class="tabled ">
          <td class="col-3 "> <span class="ms-3"> <?php echo $reportData['numReport']; ?> </span> </td>
          <td class="col-3 text-center">
            <?php
              date_default_timezone_set('Asia/Riyadh');
              $dateTime = date('d/m/Y', strtotime($reportData['dateTime']));
              echo $dateTime;
            ?>
          </td>
          <td class="col-3 text-center"> <?php echo $status; ?> </td>
          <td class="col-5 text-center"> <?php echo $implementedReports; ?> </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

<div class="d-flex  mt-5">
  <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
</script>
<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
<script>

</script>
</body>

</html>