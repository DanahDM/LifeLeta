<?php

    use App\Models\Firestore;

    require_once "vendor/autoload.php";
    $db = new Firestore();
    $collection = $db->setCollectionName('Employee');

    if (isset($_POST['deleteId'])) {
        // استرجاع رقم الموظف المطلوب للحذف
        $deleteId = $_POST['deleteId'];
        $data = $collection->setDocumentName($deleteId);
        // حذف المستند من Firestore باستخدام رقم الموظف كمعرف
        $data->deleteDocument($deleteId);
    }

?>