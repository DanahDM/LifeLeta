<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");
?>

<div class="container m-5 p-5">
    <div class="row justify-content-center gap-5" style="padding-left: 0rem; padding-right: 0rem;">
        <div class="row notfication-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
            <div class="row justify-content-start pt-1 gap-5" style="padding-left: 0rem; padding-right: 0.5rem;">
                <div class="col-9 pt-2">
                    <img alt="not found" src="./public/notification.svg" height="26px">
                    <span class="ms-2" height="40px"> تنبيه تأخير فيه تنفيذ بلاغ </span>
                </div>
                <div class="col-2 pt-1 justify-content-end">
                    <div class="notf-noread pt-1">
                        <span class="text-center align-middle "><b> غير مقروء </b></span>
                    </div>
                </div>
            </div>
            <div class="col-md-10 justify-content-start ms-2 ">
                <b class="text-dark"> رقم البلاغ: </b>
                <span class="notf-con ms-2"> PM 2:00 - 7\11\2023 - 10015456 </span>
            </div>
        </div>
        <div class="row notfication-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
            <div class="row justify-content-start pt-1 gap-5" style="padding-left: 0rem; padding-right: 0.5rem;">
                <div class="col-9 pt-2">
                    <img alt="not found" src="./public/notification.svg" height="26px">
                    <span class="ms-2" height="40px"> تحديث بلاغ </span>
                </div>
                <div class="col-2 pt-1 justify-content-end">
                    <div class="notf-noread pt-1">
                        <span class="text-center align-middle "><b> غير مقروء </b></span>
                    </div>
                </div>
            </div>
            <div class="col-md-10 justify-content-start ms-2 ">
                <b class="text-dark"> رقم التعريفي للموظف: </b>
                <span class="notf-con ms-2"> 1115390876 </span>
            </div>
        </div>
        <div class="row notfication-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
            <div class="row justify-content-start pt-1 gap-5" style="padding-left: 0rem; padding-right: 0.5rem;">
                <div class="col-9 pt-2">
                    <img alt="not found" src="./public/readnotification.svg" height="26px">
                    <span class="ms-2" height="40px"> تنبيه ULTRASONIC </span>
                </div>
                <div class="col-2 pt-1 justify-content-end">
                    <div class="notf-read pt-1">
                        <span class="text-center align-middle "><b> مقروء </b></span>
                    </div>
                </div>
            </div>
            <div class="col-md-10 justify-content-start ms-2 ">
                <b class="text-dark"> رقم الحساس: </b>
                <span class="notf-con ms-2"> A123 </span>
            </div>
        </div>
        <div class="row notfication-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
            <div class="row justify-content-start pt-1 gap-5" style="padding-left: 0rem; padding-right: 0.5rem;">
                <div class="col-9 pt-2">
                    <img alt="not found" src="./public/readnotification.svg" height="26px">
                    <span class="ms-2" height="40px"> تنبيه تأخير فيه تنفيذ بلاغ </span>
                </div>
                <div class="col-2 pt-1 justify-content-end">
                    <div class="notf-read pt-1">
                        <span class="text-center align-middle "><b> مقروء </b></span>
                    </div>
                </div>
            </div>
            <div class="col-md-10 justify-content-start ms-2 ">
                <b class="text-dark"> رقم البلاغ: </b>
                <span class="notf-con ms-2"> PM 2:00 - 17\11\2023 -10015456 </span>
            </div>
        </div>
    </div>
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
</script>
<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>