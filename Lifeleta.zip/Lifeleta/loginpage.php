<?php
  include_once("./includes/header.php");

  use App\Models\Firestore;

  // استرجاع قيم الكوكيز إذا كانت موجودة
  $rememberMeID = isset($_COOKIE['remember_me_id']) ? $_COOKIE['remember_me_id'] : "";
  $rememberMePassword = isset($_COOKIE['remember_me_password']) ? $_COOKIE['remember_me_password'] : "";

  if (isset($_POST['login'])) {
    require_once "vendor/autoload.php";
    $db = new Firestore();
    $collection = $db->setCollectionName('Admin');
    $ID = $_POST['logID'];
    $password = $_POST['logPass'];

    $data = [
      'ID' => $ID,
      'Password' => $password,
    ];

    $collection->login($data);

    if (isset($_POST['remember_me'])) {

      // تحقق مما إذا تم تحديد خانة "تذكرني"
      $expire = time() + (30 * 24 * 60 * 60); // يمكنك تعيين فترة انتهاء الصلاحية هنا (على سبيل المثال، 360 يومًا)
      setcookie("remember_me_id", $ID, $expire); // حفظ معرّف المستخدم في الكوكيز
      setcookie("remember_me_password", $password, $expire); // حفظ كلمة المرور في الكوكيز
    } else {
      setcookie("remember_me_id", "", time() - 3600); // إزالة الكوكيز
      setcookie("remember_me_password", "", time() - 3600); // إزالة الكوكيز
    }
  }
?>

<body class="bg-white">
  <div class="login1">
    <img class="login-child" alt="not found" src="./public/rectangle-120@2x.png">
    <b class="b1 mt-1">تسجيل الدخول </b>
  </div>
  <div class="container-fluid">
    <div class="text-center">
      <img src="./public/logo1@2x.png" width="220px" height="130px" class="align-top" alt="Logo" loading="lazy">
    </div>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <form class="needs-validation mt-4" id="Formlogin" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" style="font-size: var(--font-size-xs);">
          <div class=" idlog form-group pt-4">
            <label for="logID" class="form-label pslog"> الرقم التعريفي</label>
            <div class="inputl">
              <input type="number" class="form-control inputidlog" id="logID" name="logID" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" placeholder="أدخل الرقم التعريفي" required>
            </div>
          </div>
          <div class="idlog form-group pt-4 pb-3">
            <label for="logPass" class="form-label pslog">كلمة المرور</label>
            <div class="inputl">
              <input type="password" class="form-control inputidlog" name="logPass" id="logPass" placeholder="أدخل كلمة المرور" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);"  required>
            </div>
          </div>
          <div class="ps-3">
            <div class="col-8 pb-2">
              <a id="reg" href="#" onclick="addNumberToLink()" class="link-success link-offset-1" style="color: var(--color-teal);"> نسيت كلمة المرور؟
              </a>
              <span class="invalid-feedback ms-3" id="alert" style="display: inline;"> </span>
            </div>
            <div class="col-4 pt-2 pb-2">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="remember_me" name="remember_me">
                <label class="form-check-label" for="remember_me">
                  تذكرني
                </label>
              </div>
            </div>
          </div>

          <div class="text-center">
            <div class="text-center">
              <button type="submit" class="btn btn-secondary btnl" name="login" value="login">
                تسجيل الدخول </button>
            </div>
            <div class="align-content-center gap-lg-4 mt-2" style="letter-spacing: 0.03em; font-weight: 600; font-size: 18px; font-family: var(--font-poppins);">
              ليس لديك حساب؟
              <a id="reg" href="registerpage.php" class="link-success link-offset-2 link-underline link-underline-opacity-0" style="color: var(--color-teal);"> إنشاء حساب
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
  </div>
  <script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
    // قم بملء قيم الكوكيز في حقول تسجيل الدخول إذا كانت متاحة
    document.getElementById("logID").value = "<?php echo $rememberMeID; ?>";
    document.getElementById("logPass").value = "<?php echo $rememberMePassword; ?>";

    function addNumberToLink() {
      var number = document.getElementById("logID").value;
      var alert = document.getElementById("alert");
      if (number === "") {
        alert.textContent = "من فضلك ادخل الرقم التعريفي . ";
        alert.classList.add("alert-danger");
      } else {
        var link = document.getElementById("reg");
        link.href = "restpass.php?ID=" + number;
      }
    }
  </script>
</body>

</html>