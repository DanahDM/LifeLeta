<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");

    use App\Models\Firestore;
    require_once "vendor/autoload.php";

    include_once("SensorReadings.php");

    $db = new Firestore();
    $db->setCollectionName('Report');

    $reportsRef = $db->firestore->collection('Report')->documents();

    $employeesRef = $db->firestore->collection('Employee')->documents();
    $employeesData = [];

    foreach ($employeesRef as $employeeDoc) {
        $employeeData = $employeeDoc->data();

        // استعلام قاعدة البيانات للحصول على عدد البلاغات المسجلة باسم الموظف
        $processingReportsRef = $db->firestore->collection('Report')
            ->where('idEmployee', '=', $employeeData['id'])
            ->where('status', '=', 'Processing')
            ->documents();

        $processingReports = $processingReportsRef->size();

        // إضافة البيانات إلى مصفوفة الموظفين
        $employeesData[] = [
            'employeeId' => $employeeData['id'],
            'name' => $employeeData['name'],
            'processingReports' => $processingReports,
        ];
    }

?>

<div class="d-flex justify-content-center py-5 m-3">
    <div class="col-md-6" style="background-color: var(--color-teal-100); border-radius: 10px;">
        <button type="button" class="btn btn-light btn2 m-3 ms-4" style="background-color: var(--color-silver);">
            <a class="nav-link d-flex align-items-center" href="announcements-Safiex.php?announcements"> <b class="ms-4 me-4">
                    البلاغات
                    الجـديدة </b> </a>
        </button>
        <button type="button" class="btn btn-light btn2 m-3 ">
            <a class="nav-link d-flex align-items-center" href="announcements.php?announcements"> <b class="ms-4 me-4"> البلاغات
                    الحـالية </b> </a>
        </button>
        <button type="button" class="btn btn-light btn2 m-3 ">
            <a class="nav-link d-flex align-items-center" href="announcements-Prefiex.php?announcements"> <b class="ms-4 me-4">
                    البلاغات
                    السـابقة </b> </a>
        </button>
    </div>
</div>

<div class="container-fluid pt-5 pb-3">
    <div class="row justify-content-center gap-5" style="padding-left: 0rem; padding-right: 0rem;">
        <?php foreach ($reportsRef as $reportDoc) {
            $reportData = $reportDoc->data();
            if ($reportData['status'] !== 'Suspended') {
                continue;
            }
        ?>
            <div class="row announc-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
                <div class="row justify-content-start pt-1 " style="padding-left: 0rem; padding-right: 0.5rem;">
                    <div class="col-8 pt-2">
                        <img alt="not found" src="./public/announcement.svg" height="30px">
                        <span class="ms-2" height="36px" style=" vertical-align: bottom;"> <?php echo $reportData['subject']; ?> </span>
                    </div>
                    <div class="col-9 justify-content-start">
                        <span class="announc-con ms-4 mt-2">
                            <?php
                                date_default_timezone_set('Asia/Riyadh');
                                $dateTime = date('d/m/Y - h:i A', strtotime($reportData['dateTime']));
                                echo $reportData['numReport'] . ' - ' . $dateTime;
                            ?>
                        </span>
                    </div>
                    <div class="col-2 ms-4 justify-content-end ">
                        <div class="announc-type">
                            <span class="text-center mt-2"> بلاغ جـديد </span>
                        </div>
                    </div>
                    <div class="col-8 pt-4">
                        <div class="announc-text">
                            <div class="m-4 pt-3">
                                <?php echo $reportData['description']; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-8 pt-3 ms-5 justify-content-start">
                        <img alt="not found" src="./public/address.svg" height="30px">
                        <span class="announc-con ms-2"> <?php echo $reportData['location']['country']; ?> </span>
                    </div>
                    <div class="col-md-8 pt-3 ms-5 pb-4 justify-content-md-evenly align-items-center">
                        <div class="text-center">
                            <button type="button" class="btn btn-primary btnl ms-5">
                                <a class="nav-link report-link" data-bs-toggle="modal" data-bs-target="#selectempModal" href="#selectempModal">
                                    <input type="hidden" class="report-id" value="<?php echo $reportDoc->id(); ?>">
                                    تعـيـين
                                </a>
                            </button>
                            <button type="button" class="btn btn3 btn-secondary ms-5">
                                <a class="nav-link" href="display-Announcements.php?announcements&IdRep=<?php echo $reportDoc->id(); ?>"> عــرض </a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<div class="modal fade select-icon pb-5" id="selectempModal" tabindex="-1" aria-labelledby="selectempModal" aria-hidden="true" data-bs-backdrop="true">
    <div class="modal-dialog selectemp-icon">
        <div class="modal-content border-0 ">
            <div class="modal-body border-0 mt-2 pb-5" style="margin-bottom: 10px;">
                <div class="text-center ">
                    <span class="fw-bolder text-center"> فضلاً أختر موظف </span> <br>
                </div>
                <div class="row justify-content-center gap-4 mt-3" style="padding-left: 0rem; padding-right: 0rem;">
                    <?php foreach ($employeesData as $employee) : ?>
                        <div class="row emps-icon" style="display: flex; padding-left: 0rem; padding-right: 0rem;">
                            <div class="row justify-content-start pt-1 gap-5" style="padding-left: 0rem; padding-right: 0.5rem;">
                                <div class="col-md-10 pt-2">
                                    <a class="nav-link assign-link" data-bs-toggle="modal" data-bs-target="#valditeselectempModal" href="#valditeselectempModal">
                                        <input type="hidden" class="emp-id" value="<?php echo $employee['employeeId']; ?>">
                                        <input type="hidden" class="emp-name" value="<?php echo $employee['name']; ?>">
                                        <input type="hidden" class="reportid" value="">
                                        <b class="ms-2"> موظف: <?php echo $employee['name']; ?> </b>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-12 justify-content-start ms-2 ">
                                <b class="nom text-dark"> الرقم التعريفي: </b>
                                <span class="nom ms-2"> <?php echo $employee['employeeId']; ?> </span>
                            </div>
                            <div class="col-md-10 justify-content-start ms-2 ">
                                <b class="nom text-dark"> الحالات المسجلة: </b>
                                <span class="nom ms-2"> <?php echo $employee['processingReports']; ?> </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade delete-icon" id="valditeselectempModal" tabindex="-1" aria-labelledby="valditeselectempModalLabel" aria-hidden="true" data-bs-backdrop="true">
    <div class="modal-dialog del-icon">
        <div class="modal-content border-0">
            <div class="modal-header border-0">
            </div>
            <div class="modal-body border-0 text-center" height="60px" style="margin-top: 20px; margin-bottom: 10px;">
                <span class="fw-bold "> هل أنت متأكد من تعيـين </span> <br>
                <span class="fw-bold text-dark "> </span>
            </div>
            <div class="modal-footer justify-content-md-evenly align-items-center border-0">
                <button type="button" class="btn btn-primary btnl"> نـعـم </button>
                <button type="button" class="btn btn-secondary btn3" data-bs-dismiss="modal"> إلغاء </button>
            </div>
        </div>
    </div>
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
    
    const reportlink = document.querySelectorAll('.report-link');
    reportlink.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const reportId = link.querySelector('.report-id').value;
            const selectempModal = document.getElementById('selectempModal');
            const reportIdFields = selectempModal.querySelectorAll('.reportid');
            reportIdFields.forEach(field => {
                field.value = reportId;
            });
        });
    });

    const assignLinks = document.querySelectorAll('.assign-link');
    assignLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const empId = link.querySelector('.emp-id').value;
            const empName = link.querySelector('.emp-name').value;
            const reportid = link.querySelector('.reportid').value;
            const selectModal = document.getElementById('valditeselectempModal');
            const selectModalText = selectModal.querySelector('.modal-body span.text-dark');
            selectModalText.textContent = empName + ' .';

            const selectButton = selectModal.querySelector('.btn-primary');
            selectButton.addEventListener('click', () => {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'assignEmpReport.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        alert("تم تعيين   " + empName + " بنجاح لتنفيذ هذا البلاغ.");
                        selectModal.style.display = 'none';
                        window.close();
                    }
                };
                xhr.send('empId=' + empId + '&reportid=' + reportid);
                window.open('announcements-Safiex.php', '_self');
            });
        });
    });
</script>

<script src="./bootstrap/js/bootstrap.min.js"></script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>