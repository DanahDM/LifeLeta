<?php
    include_once("./includes/header.php");
    include_once("./includes/mainnav.php");
?>
<div class="frame2 mt-5">
    <div class="frame3">
        <div class="frame-inner">
            <img class="rectangle-icon" alt="" src="./public/rectangle-117.svg">
        </div>
        <div class="parent">
            <img class="icon" alt="" src="./public/--.svg">
            <img class="icon1" alt="" src="./public/-.svg">
        </div>
    </div>
</div>
<div class="container">
    <div class="text-center">
        <div class=" align-content-center">
            <img src="./public/logo1@2x.png" width="330px" height="190px" class="align-top" alt="Logo" loading="lazy">
        </div>
        <div class="align-content-center gap-lg-4 p-3 mt-4">
            <a id="log" href="loginpage.php" class="link-success link-offset-2 link-underline link-underline-opacity-0 rounded-3 p-3 text-white" style="background-color: var(--color-teal); 
                        font-family: var(--font-poppins); letter-spacing: 0.03em; font-weight: 600; font-size: 18px;">
                <span class=" ms-3 me-3"> تسجيل الدخول </span></a>
        </div>
        <div class="align-content-center gap-lg-4 mt-2" style="letter-spacing: 0.03em; font-weight: 600; font-size: 18px; font-family: var(--font-poppins);">
            ليس لديك حساب؟
            <a id="reg" href="registerpage.php" class="link-success link-offset-2 link-underline link-underline-opacity-0" style="color: var(--color-teal);"> إنشاء حساب
            </a>
        </div>
    </div>
</div>
<div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<div class="d-flex justify-content-center  mt-4 mb-4">
    <img alt="" src="./public/rectangle-126.svg" height="65px" class="mt-1">
    <Span class="ms-4 fw-bold" style="color: var(--color-teal); font-size: 48px; letter-spacing: 0.01em;">
        نبذة عنا </Span>
</div>
<div class="frame-parent1 bg-white">
    <div class="frame-child1">
        <div class="text-end mt-3 " style="margin-left: 400px;">
            <Span class="fw-bold" style="color: var(--color-darkslategray); font-size: 30px; font-family: var(--font-dongle);">
                رؤيتنا </Span>
        </div>
        <div class="text-end" style="margin-left: 380px; margin-top: -5px;">
            <img alt="" src="./public/rectangle-2.svg" width="100px;">
        </div>
        <div class="text-start" style="margin-left: 80px; margin-right: 600px; margin-top: 15px;">
            <Span class="fw-bold" style="color: var(--color-darkslategray); font-size: 30px; font-family: var(--font-roboto);">
                رؤيتنا توفير مجتمع متعاون وبيئة صحية وأمنة عن طريق حل مشكلة الفيضانات وتحقيق استجابة سريعة للسلطات
                والمواطنين. </Span>
        </div>
    </div>
    <img class="image-75-icon" alt="" src="./public/image-75@2x.png">
</div>
<div class="frame-parent1 bg-white">
    <div class="frame-child1" style="height: 230px;">
        <div class="text-start mt-3 " style="margin-right: 500px;">
            <Span class="fw-bold" style="color: var(--color-darkslategray); font-size: 30px; font-family: var(--font-dongle);">
                رسالتنا </Span>
        </div>
        <div class="text-start" style="margin-right: 480px; margin-top: -5px;">
            <img alt="" src="./public/rectangle-2.svg" width="100px">
        </div>
        <div class="text-start" style="margin-right: 240px; margin-left: 500px; margin-top: 15px;">
            <Span class="fw-bold" style="color: var(--color-darkslategray); font-size: 30px; font-family: var(--font-roboto);">
                رسالتنا حماية حياة وممتلكات المواطنين وتعزيز السلامة العامة من خلال إنشاء نظام انذار مبكر للفيضانات
                وتوفير بيئة صحية من خلال الاستجابة السريعة لبلاغات المواطنين ومتابعتها. </Span>
        </div>
    </div>
    <img class="image-icon" alt="" src="./public/image-74@2x.png">
</div>
<div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
</div>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });
</script>
<script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>