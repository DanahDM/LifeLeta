<?php
  include_once("./includes/header.php");

  use App\Models\Firestore;

  if (isset($_GET['ID'])) {
    $ID = $_GET['ID'];
  }

  if (isset($_POST['res'])) {
    require_once "vendor/autoload.php";
    $db = new Firestore();
    $collection = $db->setCollectionName('Admin');
    $password = $_POST['password'];
    $ID = $_POST['id'];

    $data = [
      ['path' => 'Password', 'value' => $password]
    ];

    $collection->updateDocument($ID, $data);
    echo "<script>window.open('loginpage.php','_self')</script>";
  }
?>

<body class="bg-white">
  <div class="login1">
    <img class="login-child" alt="not found" src="./public/rectangle-120@2x.png">
    <b class="b1 mt-1"> تغيير كلمة المرور </b>
  </div>
  <div class="container-fluid">
    <div class="text-center">
      <img src="./public/logo1@2x.png" width="220px" height="130px" class="align-top" alt="Logo" loading="lazy">
    </div>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <form class="mt-4 needs-validation" id="myform" method="post" style="font-size: var(--font-size-xs);" action="<?php echo $_SERVER['PHP_SELF']; ?>">
          <div class=" idlog pt-4">
            <label for="password" class="form-label pslog"> كلمة المرور الجديدة </label>
            <div class="inputl">
              <input class="form-control inputidlog" name="password" id="password" placeholder="أدخل كلمة المرور" type="password" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" required />
            </div>
          </div>
          <div class="idlog pt-4 pb-3">
            <label for="confirm-password" class="form-label pslog"> تأكيد كلمة المرور </label>
            <div class="inputl">
              <input class="form-control inputidlog" name="confirm-password" id="confirm-password" placeholder="أدخل كلمة المرور" type="password" style="width: 380px; box-shadow: none; border: 1px solid var(--color-darkslategray);" required />
            </div>
            <div class="invalid-feedback">
              <i class="bi bi-x-circle-fill text-black"></i>
            </div>
            <div class="valid-feedback">
              <i class="bi bi-check-circle-fill text-black"></i>
            </div>
          </div>
          <div class="col-md-10">
            <span class="invalid-feedback ms-5" id="alert" style="display: grid;"> </span>
          </div>
          <div class="col-md-4">
            <input type="hidden" name="id" value="<?php echo $ID; ?>">
          </div>
          <div class="p-3 text-center">
            <button type="submit" class="btn btn-secondary btnl me-5" name="res" value="res" onclick="onSubmit()">
              تغيير</button>
            <button type="button" class="btn btn-secondary btnl me-5 ms-2" onclick="window.history.back()">
              إلغاء </button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="d-flex  mt-5">
    <img alt="" src="./public/frame-7042.svg" width="100%">
  </div>
  <script>
    window.addEventListener('DOMContentLoaded', (event) => {
      document.documentElement.setAttribute('data-bs-theme', 'light');
    });

    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm-password");

    function validatePassword() {
      if (password.value != confirm_password.value) {
        confirm_password.setCustomValidity("");
        confirm_password.classList.remove("is-valid");
        confirm_password.classList.add("is-invalid");
      } else {
        confirm_password.setCustomValidity("");
        confirm_password.classList.remove("is-invalid");
        confirm_password.classList.add("is-valid");
      }
    }

    password.onkeyup = validatePassword;
    confirm_password.onkeyup = validatePassword;
    var form = document.getElementById("myform");
    
    function onSubmit() {
      var alert = document.getElementById("alert");
      form.addEventListener("submit", function(event) {
        
        if (password.value === confirm_password.value) {
          form.submit();
        } else {
          event.preventDefault();
          alert.textContent = "كلمة السر غير مطابقة يرجى ادخال نفس كلمة السر.";
          alert.classList.add("alert-danger");
          alert.classList.remove("d-none");
        }
      });
    }
  </script>

  <script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./bootstrap/js/bootstrap.min.js"></script>
</body>

</html>